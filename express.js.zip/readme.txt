

Changes from TodoMVC AngularJS template
=======================================
I took the source and did the following changes before actually start programming
the exercise:
* all files                 - replaced tabs with spaces
* todomvc-common/base.js    - left only the underscore initialization
* todomvc-common/base.css   - removed everything related to the Learn section
* index.html                - removed footer, documented everything that stayed
                              to clarify that I know what it is for, extracted
                              index template to partial
* removed test directory
* removed bower.json

